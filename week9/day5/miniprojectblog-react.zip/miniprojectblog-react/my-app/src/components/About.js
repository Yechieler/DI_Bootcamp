import React from 'react';
// import blog from './blog'

export default function About() {
    return (
        <div className='container'>
            <h3 className='center'>About</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati tempora eius ipsum saepe quasi sapiente quam eligendi voluptates fugit porro asperiores mollitia voluptatem debitis ipsa earum reprehenderit eos, soluta aperiam!</p>
        </div>
    )
}