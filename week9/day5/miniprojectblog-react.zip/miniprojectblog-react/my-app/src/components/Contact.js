import React from 'react'

const Contact = ()=> {
    return (
        <div className='container'>
            <h3 className='center'>Contact</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati tempora eius ipsum saepe quasi sapiente quam eligendi voluptates fugit porro asperiores mollitia voluptatem debitis ipsa earum reprehenderit eos, soluta aperiam!</p>
        </div>
    )
}

export default Contact;